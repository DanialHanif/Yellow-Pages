#include <iostream>
#include "User.h"
#include "Nodes.h"

#ifndef MANAGEMENT_H
#define MANAGEMENT_H

class Management {

	private:
		User userData;
		Company companyLists;
		Job jobLists;
		Service serviceLists;
		Hotel hotelLists;



};

#endif
